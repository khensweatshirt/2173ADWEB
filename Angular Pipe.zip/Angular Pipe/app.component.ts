import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { interval } from 'rxjs';
import { map } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-pipe'
  presentDate = new Date(); 
  time$: Observable <Date>;
  fruits = ['Apple', 'Banana', 'Orange', 'Mango', 'Grapes'];
  text = 'Angular is a platform for building web applications';
  price = 1234.56;
  pi = 3.14159265359;
  number = 1234567.89;
  numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  startIndex = 0;
  endIndex = 5;
  percentage = 0.75;

  
updateSlice(start: number, end: number) {
    this.startIndex = start;
    this.endIndex = end;
  }
date: object = {
  name: 'Winston', age:22, food: 'Ramen',
  language: [
    {lname: '35', level: 'Wizard'},
    {lname: 'Python', level: 'Master'},
    {lname: 'Cobol', level: 'Beginner'}
    
  ]
}

constructor(){
  this.time$ = interval(1000).pipe (
  map(() => new Date())
  );
}
}